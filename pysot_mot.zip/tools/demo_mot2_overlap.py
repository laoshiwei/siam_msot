#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 17 15:43:22 2022

@author: atur
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import argparse
import random
import cv2
import torch
import numpy as np
from glob import glob


from pysot.core.config import cfg
from pysot.models.model_builder import ModelBuilder
from pysot.tracker.tracker_builder import build_tracker

torch.set_num_threads(1)

parser = argparse.ArgumentParser(description='tracking demo')
parser.add_argument('--config', type=str, help='config file')
parser.add_argument('--snapshot', type=str, help='model name')
parser.add_argument('--video_name', default='', type=str,
                    help='videos or image files')
args = parser.parse_args()


def get_frames(video_name):
    if not video_name:
        cap = cv2.VideoCapture(0)
        # warmup
        for i in range(5):
            cap.read()
        while True:
            ret, frame = cap.read()
            if ret:
                yield frame
            else:
                break
    elif video_name.endswith('avi') or \
        video_name.endswith('mp4'):
        cap = cv2.VideoCapture(args.video_name)
        while True:
            ret, frame = cap.read()
            if ret:
                yield frame
            else:
                break
    else:
        images = glob(os.path.join(video_name, '*.jp*'))
        images = sorted(images,
                        key=lambda x: int(x.split('/')[-1].split('.')[0]))
        for img in images:
            frame = cv2.imread(img)
            yield frame  
            
def iou(boxA, boxB):
	# determine the (x, y)-coordinates of the intersection rectangle
	xA = max(boxA[0], boxB[0])
	yA = max(boxA[1], boxB[1])
	xB = min(boxA[2]+boxA[0], boxB[2]+boxB[0])
	yB = min(boxA[3]+boxA[1], boxB[3]+boxB[1])
	# compute the area of intersection rectangle
	interArea = max(0, xB - xA + 1) * max(0, yB - yA + 1)
	# compute the area of both the prediction and ground-truth
	# rectangles
	boxAArea = (boxA[2] + 1) * (boxA[3] + 1)
	boxBArea = (boxB[2] + 1) * (boxB[3] + 1)
	# compute the intersection over union by taking the intersection
	# area and dividing it by the sum of prediction + ground-truth
	# areas - the interesection area
	iou = interArea / float(boxAArea + boxBArea - interArea)
	# return the intersection over union value
	return iou

def biggest_overlap(boxA, boxes):
    big_over = 0
    for i,boxB in enumerate(boxes):
        result = iou(boxA, boxB)
        if result > big_over:
            big_over = result
            ind = i
        else:
            ind = -1
    return ind

"""def distance(pt_1, pt_2):
    pt_1 = np.array((pt_1[0], pt_1[1]))
    pt_2 = np.array((pt_2[0], pt_2[1]))
    return np.linalg.norm(pt_1-pt_2)

def closest_node(node, nodes):
    pt = []
    dist = 9999999
    for i,n in enumerate(nodes):
        if distance(node, n) <= dist:
            dist = distance(node, n)
            pt = n
            ind = i
    #print(dist)
    return pt,i"""
from scipy.spatial import distance

def closest_node(node, nodes):
    closest_index = distance.cdist([node], nodes).argmin()
    return nodes[closest_index],int(closest_index)

def main():
    # load config
    cfg.merge_from_file(args.config)
    cfg.CUDA = torch.cuda.is_available() and cfg.CUDA
    device = torch.device('cuda' if cfg.CUDA else 'cpu')
    # create model
    model = ModelBuilder()
    # load model
    model.load_state_dict(torch.load(args.snapshot, map_location=lambda storage, loc: storage.cpu()))
    model.eval().to(device)
    # build tracker
    tracker = build_tracker(model)
    
    #yolov5
    yolo_model = torch.hub.load('ultralytics/yolov5', 'yolov5x6')
                               
    first_frame = True
    if args.video_name:
        video_name = args.video_name.split('/')[-1].split('.')[0]
    else:
        video_name = 'webcam'
    cv2.namedWindow(video_name, cv2.WND_PROP_FULLSCREEN)
    
    track_center = [] * 30 
    prev_frame = []
    tracker_list = []
    
    for i, frame in enumerate(get_frames(args.video_name)):
        
        if first_frame:
            yolo_img = yolo_model(frame)
            #get detection results and turn into list
            # output: x1           y1           x2           y2   confidence        class
            detect = yolo_img.xyxy[0].tolist()
            tracker_list = []
            for i in range(len(detect)):
                #selectROI needs to return x,y,width,height
                init_rect = (int(detect[i][0]),int(detect[i][1]),\
                             int(detect[i][2]-detect[i][0]),int(detect[i][3]-detect[i][1]))
                tracker = build_tracker(model)    
                tracker.init(frame, init_rect)
                tracker_list.append(tracker)
            first_frame = False
            cv2.imshow(video_name, frame)

        elif i%20==0:
             yolo_img = yolo_model(frame)
             #get detection results and turn into list
             # output: x1           y1           x2           y2   confidence        class
             detect = yolo_img.xyxy[0].tolist()
             init_list = []
             detector_centres = []
             #print("detect length", len(detect))
             
             for i in range(len(detect)):
                 #selectROI needs to return x,y,width,height
                 init_rect = (int(detect[i][0]),int(detect[i][1]),\
                              int(detect[i][2]-detect[i][0]),int(detect[i][3]-detect[i][1]))
                 init_list.append(init_rect)
                 centre_rect = ((int(detect[i][0])+ int(detect[i][2]))/2, (int(detect[i][1])+ int(detect[i][3]))/2)
                 detector_centres.append(tuple(centre_rect))
                      
             #for all detections, either assign to prev tracker, start -1 tracker, or append to track_list and start for remaning init not_chosens   
             init_not_chosen = [False] * len(init_list)   
             #print("true false",init_not_chosen, "length", len(init_not_chosen))
             #print("tracker length beforehand", len(tracker_list))#, " list " , tracker_list)
             
             for i, tracker in enumerate(tracker_list):
                 #if tracker is not erased
                 if tracker_list[i] != -1:
                     index = biggest_overlap(prev_frame[i],init_list)
                     #no overlap
                     if index == -1:
                         prev_centre = tuple((prev_frame[i][0]+prev_frame[i][2], prev_frame[i][1]+prev_frame[i][3]))
                         result, index = closest_node(prev_centre, detector_centres)
                     if init_not_chosen[index] == False:
                         tracker.init(frame, init_list[index])
                         init_not_chosen[index] = True
                         #print("tracker length if", len(tracker_list))#, " list " , tracker_list)
                     else:
                         trackk =tracker_list[i]
                         del trackk
                         tracker_list[i] = -1
                 else:
                     for index, turn in enumerate(init_not_chosen):
                         if turn==False:
                             tracker = build_tracker(model)
                             tracker.init(frame, init_list[index])
                             init_not_chosen[index] =True
                             break
                         
                     tracker_list[i] = tracker
                     track_center[i] = []
                     #find empty space for tracker
                     #print("tracker length else", len(tracker_list))#, " list " , tracker_list)
             #print("true false",init_not_chosen, "length", len(init_not_chosen))
             for i, turn in enumerate(init_not_chosen):
                 if turn == False:
                     tracker = build_tracker(model)
                     tracker.init(frame, init_list[i])
                     tracker_list.append(tracker)
                     init_not_chosen[i] =True
                     
                     
             #print("tracker length final for", len(tracker_list))#, " list " , tracker_list)
             #print("true false",init_not_chosen, "length", len(init_not_chosen))
             #cv2.imshow(video_name, frame)
             #cv2.waitKey(4000)
        else:
            #print("tracker length else", len(tracker_list))
            prev_frame = [] * len(tracker_list)
            for i, tracker in enumerate(tracker_list):

                #if tracker not empty
                if tracker != -1:
                    outputs = tracker.track(frame)
                    #print(outputs)
                    bbox = list(map(int, outputs['bbox']))
                    #prev frame centres
                    #prev_frame[i] = Point(outputs['center'][0], outputs['center'][1])
                    #prev_frame.append(tuple((outputs['center'][0], outputs['center'][1])))
                    prev_frame.append(tuple((bbox[0], bbox[1],bbox[2], bbox[3])))
                    try:
                        #track_center[i].append(Point(outputs['center'][0], outputs['center'][1]))
                        track_center[i].append(tuple((outputs['center'][0], outputs['center'][1])))
                    #add to it if i index empty
                    except: 
                        track_center.append([])
                        #track_center[i].append(Point(outputs['center'][0], outputs['center'][1]))
                        track_center[i].append(tuple((outputs['center'][0], outputs['center'][1])))
                        
                        
                    if outputs['best_score'] < 0.2:
                        trackk =tracker_list[i]
                        del trackk
                        tracker_list[i] = -1
                        track_center[i] = []
                        #print(track_center)
                        print("tracker removed", i)
                    else:
                        cv2.rectangle(frame, (bbox[0], bbox[1]),
                                      (bbox[0]+bbox[2], bbox[1]+bbox[3]),
                                      (0, 255, 0), 2)
                        cv2.putText(frame, str(i), (bbox[0]+2,bbox[1]+2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,0,0), 1)
                        for i in range(len(track_center)):
                            color = tuple((random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
                            for point in range(len(track_center[i])-1):
                                cv2.line(frame,(int(track_center[i][point][0]),int(track_center[i][point][1])),(int(track_center[i][point+1][0]),int(track_center[i][point+1][1])),color,1)
                                #cv2.circle(frame, (int(circ[0]),int(circ[1])), radius=2, color=(255, 0, 255), thickness=-1)
                else:
                    #prev_frame[i] = Point(-20000,-20000)
                    ##ahh this causes overlaps?? 
                    #prev_frame.append(tuple((-20000,-20000)))
                    prev_frame.append(tuple((-20000,-20000,-20000,-20000)))
                    

            cv2.imshow(video_name, frame)
            cv2.waitKey(40)
            #print(prev_frame)    
        #print(track_center)        

if __name__ == '__main__':
    main()
    
"""                 model = ModelBuilder()
                 # load model
                 model.load_state_dict(torch.load(args.snapshot, map_location=lambda storage, loc: storage.cpu()))
                 model.eval().to(device)
                 # build tracker
                 
                 model_list.append(model)
                 
             for i, model in enumerate(model_list):
                 tracker = build_tracker(model)    
                 tracker.init(frame, init_list[i])
                 tracker_list.append(tracker)"""
                 
                 #before best_result if
"""                    try:
                        #track_center[i].append(Point(outputs['center'][0], outputs['center'][1]))
                        track_center[i].append([outputs['center'][0], outputs['center'][1]])
                    #add to it if i index empty
                    except: 
                        track_center.append([])
                        #track_center[i].append(Point(outputs['center'][0], outputs['center'][1]))
                        track_center[i].append([outputs['center'][0], outputs['center'][1]])"""
"""for i in range(len(tracker)):
                            if i == -1:
                                tracker_list[i] = tracker
                            else:
                                tracker_list.append(tracker)"""