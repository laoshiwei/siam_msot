
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 17 15:43:22 2022

@author: atur
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import argparse
import random
import cv2
import torch
import numpy as np
from glob import glob


from pysot.core.config import cfg
from pysot.models.model_builder import ModelBuilder
from pysot.tracker.tracker_builder import build_tracker

torch.set_num_threads(1)

parser = argparse.ArgumentParser(description='tracking demo')
parser.add_argument('--config', type=str, help='config file')
parser.add_argument('--snapshot', type=str, help='model name')
parser.add_argument('--video_name', default='', type=str,
                    help='videos or image files')
args = parser.parse_args()


def get_frames(video_name):
    if not video_name:
        cap = cv2.VideoCapture(0)
        # warmup
        for i in range(5):
            cap.read()
        while True:
            ret, frame = cap.read()
            if ret:
                yield frame
            else:
                break
    elif video_name.endswith('avi') or \
        video_name.endswith('mp4'):
        cap = cv2.VideoCapture(args.video_name)
        while True:
            ret, frame = cap.read()
            if ret:
                yield frame
            else:
                break
    else:
        images = glob(os.path.join(video_name, '*.jp*'))
        images = sorted(images,
                        key=lambda x: int(x.split('/')[-1].split('.')[0]))
        for img in images:
            frame = cv2.imread(img)
            yield frame  
            
"""def distance(pt_1, pt_2):
    pt_1 = np.array((int(pt_1[0]), int(pt_1[1])))
    pt_2 = np.array((int(pt_2[0]), int(pt_2[1])))
    return np.linalg.norm(pt_1-pt_2)

def closest_node(node, nodes):
    pt = []
    dist = 9999999
    for i,n in enumerate(nodes):
        if distance(node, n) <= dist:
            dist = distance(node, n)
            pt = n
            ind = i
    print(dist,pt,ind)
    return pt,ind"""

from scipy.spatial import distance

def closest_node(node, nodes):
    closest_index = distance.cdist([node], nodes).argmin()
    print(distance.cdist([node], nodes), nodes[closest_index],int(closest_index))
    return nodes[closest_index],int(closest_index)

def main():
    # load config
    cfg.merge_from_file(args.config)
    cfg.CUDA = torch.cuda.is_available() and cfg.CUDA
    device = torch.device('cuda' if cfg.CUDA else 'cpu')
    # create model
    model = ModelBuilder()
    # load model
    model.load_state_dict(torch.load(args.snapshot, map_location=lambda storage, loc: storage.cpu()))
    model.eval().to(device)
    # build tracker
    tracker = build_tracker(model)
   
    #yolov5
    yolo_model = torch.hub.load('ultralytics/yolov5', 'yolov5x6')
                               
    first_frame = True
    if args.video_name:
        video_name = args.video_name.split('/')[-1].split('.')[0]
    else:
        video_name='webcam'
    cv2.namedWindow(video_name, cv2.WND_PROP_FULLSCREEN)
    
    track_center = [] * 30 
    prev_frame = []
    tracker_list = []
    
    for i, frame in enumerate(get_frames(args.video_name)):
        
        if first_frame:
            yolo_img = yolo_model(frame)
            #get detection results and turn into list
            # output: x1           y1           x2           y2   confidence        class
            detect = yolo_img.xyxy[0].tolist()
            tracker_list = []
            for i in range(len(detect)):
                #selectROI needs to return x,y,width,height
                init_rect = (int(detect[i][0]),int(detect[i][1]),\
                             int(detect[i][2]-detect[i][0]),int(detect[i][3]-detect[i][1]))
                """model = ModelBuilder()
                # load model
                model.load_state_dict(torch.load(args.snapshot, map_location=lambda storage, loc: storage.cpu()))
                model.eval().to(device)"""
                tracker = build_tracker(model)   
                tracker.init(frame, init_rect)
                tracker_list.append(tracker)
            first_frame = False
            cv2.imshow(video_name, frame)

        elif i%20==0:
             #print("new", i)
             yolo_img = yolo_model(frame)
             #get detection results and turn into list
             # output: x1           y1           x2           y2   confidence        class
             detect = yolo_img.xyxy[0].tolist()
             init_list = []
             detector_centres = []
             #print("detect length", len(detect))
             
             for i in range(len(detect)):
                 #selectROI needs to return x,y,width,height
                 init_rect = (int(detect[i][0]),int(detect[i][1]),\
                              int(detect[i][2]-detect[i][0]),int(detect[i][3]-detect[i][1]))
                 init_list.append(init_rect)
                 centre_rect = ((int(detect[i][0])+ int(detect[i][2]))/2, (int(detect[i][1])+ int(detect[i][3]))/2)
                 detector_centres.append(tuple(centre_rect))
                 
             for circ in detector_centres:
                  cv2.circle(frame, (int(circ[0]),int(circ[1])), radius=2, color=(0, 0, 255), thickness=-1)
             for circ in prev_frame:
                  cv2.circle(frame, (int(circ[0]),int(circ[1])), radius=2, color=(255, 0, 255), thickness=-1)        
             #for all detections, either assign to prev tracker, start -1 tracker, or append to track_list and start for remaning init not_chosens   
             init_not_chosen = [False] * len(prev_frame)   
             #print("true false",init_not_chosen, "length", len(init_not_chosen))
             #print("tracker length beforehand", len(tracker_list))#, " list " , tracker_list)
             
             for im in range(len(init_list)):
                 
                 #find closest prev tracker
                 result, index = closest_node(detector_centres[im], prev_frame)
                 #print(prev_frame)
                 if init_not_chosen[index] == False:
                     #print("ind",index, tracker_list[index],init_list[im])
                     if tracker_list[index] != -1:
                         tracker = tracker_list[index]
                         tracker.init(frame, init_list[im])
                         init_not_chosen[index] = True
                     else:
                         tracker2 = build_tracker(model)
                         tracker2.init(frame, init_list[im])
                         tracker_list[index] = tracker2
                         init_not_chosen[index] = True
                 #if tracker used, create new
                 else:
                     tracker3 = build_tracker(model)
                     tracker3.init(frame, init_list[im])
                     tracker_list.append(tracker3)
             print("tracker length final for", len(tracker_list))#, " list " , tracker_list)
             print("true false",init_not_chosen, "length", len(init_not_chosen))
             #cv2.imshow(video_name, frame)
             #cv2.waitKey(4000)
        else:
            #print("tracker length else", len(tracker_list))
            prev_frame = [] * len(tracker_list)
            for i, tracker in enumerate(tracker_list):

                #if tracker not empty
                if tracker != -1:
                    outputs = tracker_list[i].track(frame)
                    #print(i," out",outputs )
                    bbox = list(map(int, outputs['bbox']))
                    #prev frame centres
                    #prev_frame[i] = Point(outputs['center'][0], outputs['center'][1])
                    prev_frame.append(tuple((outputs['center'][0], outputs['center'][1])))
                    
                    try:
                        #track_center[i].append(Point(outputs['center'][0], outputs['center'][1]))
                        track_center[i].append(tuple((outputs['center'][0], outputs['center'][1])))
                    #add to it if i index empty
                    except: 
                        track_center.append([])
                        #track_center[i].append(Point(outputs['center'][0], outputs['center'][1]))
                        track_center[i].append(tuple((outputs['center'][0], outputs['center'][1])))
                        
                        
                    if outputs['best_score'] < 0.2:
                        trackk =tracker_list[i]
                        del trackk
                        tracker_list[i] = -1
                        track_center[i] = []
                        #print(track_center)
                        print("tracker removed", i)
                    else:
                        cv2.rectangle(frame, (bbox[0], bbox[1]),
                                      (bbox[0]+bbox[2], bbox[1]+bbox[3]),
                                      (0, 255, 0), 2)
                        cv2.putText(frame, str(i), (bbox[0]+2,bbox[1]+2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,0,0), 1)
                        for i in range(len(track_center)):
                            color = tuple((random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
                            for point in range(len(track_center[i])-1):
                                cv2.line(frame,(int(track_center[i][point][0]),int(track_center[i][point][1])),(int(track_center[i][point+1][0]),int(track_center[i][point+1][1])),color,1)
                                #cv2.circle(frame, (int(circ[0]),int(circ[1])), radius=2, color=(255, 0, 255), thickness=-1)
                else:
                    #prev_frame[i] = Point(-20000,-20000)
                    prev_frame.append(tuple((-20000,-20000)))
            print(track_center)
            print(prev_frame) 
            #for circ in prev_frame:
            #     cv2.circle(frame, (int(circ[0]),int(circ[1])), radius=2, color=(255, 0, 255), thickness=-1)
            cv2.imshow(video_name, frame)
            cv2.waitKey(5)
        #print(track_center)        

if __name__ == '__main__':
    main()
