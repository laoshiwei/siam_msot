from .eco import ECO

def get_tracker_class():
    return ECO