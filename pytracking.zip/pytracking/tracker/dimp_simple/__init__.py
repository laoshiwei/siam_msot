from .dimp_simple import DiMPSimple

def get_tracker_class():
    return DiMPSimple